export const UPDATE_CART = "UPDATE_CART";
export const CLEAR_CART = "CLEAR_CART";
export const CART_ERROR = "CART_ERROR";
