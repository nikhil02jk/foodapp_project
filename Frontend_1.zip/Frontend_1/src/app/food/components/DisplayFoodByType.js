import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";

export const DisplayFoodByType = (props) => {
  return <div>DisplayFoodByType</div>;
};

DisplayFoodByType.propTypes = {};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DisplayFoodByType);
