package com.learning.dto;

public enum EFOOD {

	INDIAN,
	CHINESE,
	MEXICAN,
	ITALIAN
}
