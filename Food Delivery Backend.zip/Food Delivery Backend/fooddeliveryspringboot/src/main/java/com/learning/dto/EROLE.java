package com.learning.dto;

public enum EROLE {
	ROLE_USER,
	ROLE_ADMIN
}
