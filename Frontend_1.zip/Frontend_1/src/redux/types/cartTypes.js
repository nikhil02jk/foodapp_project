export const ADD_TO_CART = "add to cart";
export const REMOVE_FROM_CART = "remove from cart";
export const FETCH_CART = "fetch from cart";
export const CHECKOUT = "check out";
